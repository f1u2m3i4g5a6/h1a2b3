export enum RoomChooseType {
    AUTOMATIC,
    MANUAL
}