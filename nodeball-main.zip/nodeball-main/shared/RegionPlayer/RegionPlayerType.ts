export type RegionPlayerType = {
    region: string,
    clientId: number,
    currentRoom: string | null,
}