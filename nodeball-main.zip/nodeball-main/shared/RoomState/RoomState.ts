export enum RoomState {
    KICK_OFF_RESET,
    PAUSE,
    UNPAUSE,
    PLAY,
    GOAL_SCORE,
    GAME_ENDED
}