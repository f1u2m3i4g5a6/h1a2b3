export default interface ScoreInterface {
    red?: number,
    blue?: number,
    time?: number,
    scoreLimit: number,
    timeLimit: number
}