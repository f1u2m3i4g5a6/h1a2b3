export default {
    ROOM_ANNOUNCEMENT: "#db8822",
    FRIEND: "#28b34d",
    ERROR: "#b92626"
}