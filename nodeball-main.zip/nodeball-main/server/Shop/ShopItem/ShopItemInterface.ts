export default interface ShopItemInterface {
    id: number;
    category_id: number;
    price: number;
    type: string;
}