export default interface SceneInterface {
    name: string,
    params?: any
}