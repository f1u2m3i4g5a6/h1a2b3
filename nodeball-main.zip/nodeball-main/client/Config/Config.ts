export default {
    NAME: "NodeBall",
    SERVER_HOST: "127.0.0.1",
    SERVER_PORT: 8090,
    SERVER_UPDATE_INTERVAL: 60
}