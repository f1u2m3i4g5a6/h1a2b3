import { EN } from "./List/EN";
import { FR } from "./List/FR";

export default {
    EN: EN,
    FR: FR
}